'use client'

import React, { createContext, useContext, useState, useEffect } from 'react'

export type ThemeType = 'indigo' | 'rose' | 'emerald' | 'amber'

export const AVATARS = [
  '🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯',
  '🦁', '🐮', '🐷', '🐸', '🐵', '🦄', '🐝', '🐙', '🦖', '🐢'
]

interface SettingsContextType {
  theme: ThemeType
  setTheme: (theme: ThemeType) => void
  avatar: string
  setAvatar: (avatar: string) => void
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined)

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<ThemeType>('indigo')
  const [avatar, setAvatar] = useState<string>('🦊')
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    // Only access localStorage on client side
    const savedTheme = localStorage.getItem('bingo-theme') as ThemeType
    if (savedTheme && ['indigo', 'rose', 'emerald', 'amber'].includes(savedTheme)) {
      setTheme(savedTheme)
    }
    const savedAvatar = localStorage.getItem('bingo-avatar')
    if (savedAvatar) {
      setAvatar(savedAvatar)
    }
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted) {
      localStorage.setItem('bingo-theme', theme)
      // Update body class safely
      document.body.classList.remove('theme-indigo', 'theme-rose', 'theme-emerald', 'theme-amber')
      document.body.classList.add(`theme-${theme}`)
    }
  }, [theme, mounted])

  useEffect(() => {
    if (mounted) {
      localStorage.setItem('bingo-avatar', avatar)
    }
  }, [avatar, mounted])

  return (
    <SettingsContext.Provider value={{ theme, setTheme, avatar, setAvatar }}>
      {children}
    </SettingsContext.Provider>
  )
}

export function useSettings() {
  const context = useContext(SettingsContext)
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider')
  }
  return context
}
